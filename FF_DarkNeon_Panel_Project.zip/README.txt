FF Dark Neon Panel — Android Studio project

This is a native Android UI project for a dark-neon gaming settings panel.
It provides interactive sliders, a crosshair-style selector, switches, and a save button.
It does not modify Free Fire, automate aiming, or provide auto-headshot functionality.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync finish.
3. Select Build > Build APK(s).
4. Find the APK under app/build/outputs/apk/debug/app-debug.apk.
