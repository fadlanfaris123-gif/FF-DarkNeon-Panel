package com.example.ffdarkneon;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    final int BG = Color.rgb(5,6,16), CARD = Color.rgb(13,15,35);
    final int PURPLE = Color.rgb(177,76,255), CYAN = Color.rgb(0,205,255);
    LinearLayout page;

    GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(2, stroke);
        return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    void pad(View v, int a) { v.setPadding(a,a,a,a); }
    void addCard(String title, String subtitle) {
        LinearLayout c = column(); c.setBackground(shape(CARD, PURPLE, 20)); pad(c, 16);
        TextView h = text(title, 18, Color.WHITE, true); c.addView(h);
        TextView sub = text(subtitle, 12, 0xff9ea8ff, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=4; c.addView(sub,sp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.topMargin=12; page.addView(c,cp);
    }
    void addSwitch(String title, String detail, boolean checked) {
        LinearLayout r = row();
        LinearLayout labels = column(); labels.addView(text(title,15,Color.WHITE,true));
        labels.addView(text(detail,11,0xff9ea8ff,false));
        r.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        Switch sw = new Switch(this); sw.setButtonTintList(null); sw.setChecked(checked);
        r.addView(sw);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1,-2); rp.topMargin=12; page.addView(r,rp);
    }
    void addSlider(String label, int progress) {
        LinearLayout c = column(); LinearLayout r = row();
        r.addView(text(label,14,Color.WHITE,false),new LinearLayout.LayoutParams(0,-2,1));
        r.addView(text(progress+"%",13,CYAN,true)); c.addView(r);
        SeekBar seek = new SeekBar(this); seek.setMax(100); seek.setProgress(progress);
        c.addView(seek);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin=10; page.addView(c,p);
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(BG);
        page = column(); pad(page,18); scroll.addView(page); setContentView(scroll);

        TextView brand = text("FF PANEL  /  PRO", 26, PURPLE, true);
        page.addView(brand);
        TextView tag = text("DARK NEON • GAMING SETTINGS", 12, CYAN, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,-2); tp.topMargin=4; page.addView(tag,tp);

        LinearLayout hero = column(); hero.setGravity(Gravity.CENTER); hero.setBackground(shape(0xff10102b,CYAN,22)); pad(hero,18);
        TextView h = text("NEON CONTROL CENTER",20,Color.WHITE,true); hero.addView(h);
        TextView hs = text("Personalize your setup",13,0xffb9bfff,false); hero.addView(hs);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,-2); hp.topMargin=18; page.addView(hero,hp);

        addCard("SENSITIVITY", "Simpan preferensi kontrol untuk diatur sendiri");
        addSlider("General", 85); addSlider("Red Dot", 80); addSlider("2x Scope", 72);
        addSlider("4x Scope", 65); addSlider("Sniper Scope", 55);

        addCard("CROSSHAIR", "Pilihan tampilan latihan — tidak mengubah game");
        Spinner spinner = new Spinner(this);
        String[] styles = {"Classic Cross", "Dot", "Circle", "Minimal"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, styles);
        spinner.setAdapter(adapter); page.addView(spinner);

        addCard("QUICK SETTINGS", "Pengaturan aplikasi");
        addSwitch("Dark Neon Theme", "Tema gelap dengan aksen neon", true);
        addSwitch("Haptic Feedback", "Umpan balik sentuhan aplikasi", false);

        Button save = new Button(this); save.setText("SAVE SETTINGS");
        save.setTextColor(Color.WHITE); save.setBackground(shape(0xff5b1db5,CYAN,18));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,56); bp.topMargin=20; page.addView(save,bp);
        save.setOnClickListener(v -> Toast.makeText(this,"Pengaturan tersimpan untuk sesi ini",Toast.LENGTH_SHORT).show());

        TextView note = text("Companion UI only • no game modification",11,0xff9299c9,false);
        note.setGravity(Gravity.CENTER); LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2);
        np.topMargin=16; np.bottomMargin=18; page.addView(note,np);
    }
}
